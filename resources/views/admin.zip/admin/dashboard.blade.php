@extends('layout.admin.app')
@section('title', 'Dashboard')
@section('content')
<div class="content-wrapper">
    Yes this is Dashboard
</div>
@endsection